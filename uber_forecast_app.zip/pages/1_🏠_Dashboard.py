import streamlit as st
import plotly.express as px
from data_loader import load_data

st.markdown("<h2 style='text-align:center;'>📊 Dashboard: Uber Trips Overview</h2>", unsafe_allow_html=True)
df = load_data()
st.markdown("### 🔍 Raw Time Series Data")
st.dataframe(df.head(), use_container_width=True)

st.markdown("### 🚗 Hourly Trips Line Chart")
fig = px.line(df, x=df.index, y='trips', labels={'x': 'Timestamp', 'trips': 'Trip Count'}, title="Hourly Uber Trips")
st.plotly_chart(fig, use_container_width=True)
st.markdown("---")
st.info("Explore data here. Forecasting available in next page ➡")
