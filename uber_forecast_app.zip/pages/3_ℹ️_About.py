import streamlit as st

st.markdown("""
<h2 style='text-align:center;'>ℹ️ About This App</h2>
<p style='text-align:center;'>Built with ❤️ using Python, XGBoost, ARIMA, Prophet & Streamlit</p>
""", unsafe_allow_html=True)

st.markdown("""
---

### 📚 Dataset
- Source: NYC Taxi & Limousine Commission (FOIL Request)
- Date Range: Jan–Feb 2015
- Features: `date`, `trips`, `active_vehicles`, `dispatching_base_number`

### 🔧 Features
- Forecast hourly Uber trips
- Compare XGBoost, ARIMA, Prophet
- MAPE, R² Score, Interactive Charts
- Dark/Light mode
- Download predictions

### 👨‍💻 Developer
**Pranav Kamboji**  
[GitHub](https://github.com/kambojipranav) | [LinkedIn](https://linkedin.com/in/yourprofile)  
🧠 AI/ML | Full Stack | Data Storyteller

---

### 📜 License
This project is open source under the MIT License.
""")
